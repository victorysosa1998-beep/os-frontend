import 'package:flutter/material.dart';
import 'app_theme.dart';

/// Soft glowing brand background used on splash, onboarding and auth.
class OsBackground extends StatelessWidget {
  final Widget child;
  const OsBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Positioned.fill(child: ColoredBox(color: OsColors.bg)),
        Positioned(
          top: -140,
          left: -100,
          child: _Glow(color: OsColors.purpleDeep.withValues(alpha: .38), size: 340),
        ),
        Positioned(
          bottom: -160,
          right: -120,
          child: _Glow(color: OsColors.coral.withValues(alpha: .22), size: 360),
        ),
        Positioned.fill(child: child),
      ],
    );
  }
}

class _Glow extends StatelessWidget {
  final Color color;
  final double size;
  const _Glow({required this.color, required this.size});

  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [color, color.withValues(alpha: 0)]),
          ),
        ),
      );
}

/// OS logo mark: launcher asset if present, gradient "os" tile otherwise.
class OsLogo extends StatelessWidget {
  final double size;
  final bool showWordmark;
  const OsLogo({super.key, this.size = 64, this.showWordmark = true});

  @override
  Widget build(BuildContext context) {
    final mark = ClipRRect(
      borderRadius: BorderRadius.circular(size * .3),
      child: Image.asset(
        'assets/icon/os_launcher.png',
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          width: size,
          height: size,
          alignment: Alignment.center,
          decoration: const BoxDecoration(gradient: OsColors.brandGradient),
          child: Text(
            'os',
            style: TextStyle(
              color: Colors.white,
              fontSize: size * .46,
              fontWeight: FontWeight.w900,
              letterSpacing: -1,
            ),
          ),
        ),
      ),
    );
    if (!showWordmark) return mark;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        mark,
        SizedBox(width: size * .22),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('os',
                style: TextStyle(
                    fontSize: size * .48, fontWeight: FontWeight.w900, height: 1)),
            const SizedBox(height: 3),
            const Text('REAL CONNECTIONS',
                style: TextStyle(fontSize: 9, letterSpacing: 1.4, color: OsColors.muted)),
          ],
        ),
      ],
    );
  }
}

/// Gradient primary button.
class OsGradientButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool busy;
  final IconData? icon;
  const OsGradientButton(
      {super.key, required this.label, this.onPressed, this.busy = false, this.icon});

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !busy;
    return Opacity(
      opacity: enabled || busy ? 1 : .5,
      child: Container(
        height: 54,
        decoration: BoxDecoration(
          gradient: OsColors.brandGradient,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
                color: OsColors.purpleDeep.withValues(alpha: .35),
                blurRadius: 20,
                offset: const Offset(0, 8)),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: enabled ? onPressed : null,
            child: Center(
              child: busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Row(mainAxisSize: MainAxisSize.min, children: [
                      Text(label,
                          style: const TextStyle(
                              color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
                      if (icon != null) ...[
                        const SizedBox(width: 8),
                        Icon(icon, color: Colors.white, size: 20),
                      ],
                    ]),
            ),
          ),
        ),
      ),
    );
  }
}

/// Standard card surface.
class OsCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final EdgeInsets margin;
  final VoidCallback? onTap;
  const OsCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin = const EdgeInsets.only(bottom: 12),
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => Container(
        margin: margin,
        decoration: BoxDecoration(
          color: OsColors.surface,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: OsColors.border.withValues(alpha: .7)),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: onTap,
            child: Padding(padding: padding, child: child),
          ),
        ),
      );
}
