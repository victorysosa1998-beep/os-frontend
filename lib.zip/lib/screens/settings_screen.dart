import 'package:flutter/material.dart';
import 'package:os_dating/screens/Extras_screens.dart';
import '../services/api.dart';
import '../theme/app_theme.dart';
import '../theme/os_ui.dart';
import '../theme/user_badge.dart';


class SettingsScreen extends StatelessWidget {
  final Map<String, dynamic> user;
  final VoidCallback onLogout;
  const SettingsScreen({super.key, required this.user, required this.onLogout});

  Future<void> _confirmLogout(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        backgroundColor: OsColors.surface,
        title: const Text('Sign out?'),
        content: const Text('You will need to sign in again to see your chats.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Sign out')),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      Navigator.of(context).popUntil((r) => r.isFirst);
      onLogout();
    }
  }

  Future<void> _deleteAccount(BuildContext context) async {
    final password = await showDialog<String>(
      context: context,
      builder: (_) => const _DeleteAccountDialog(),
    );
    if (password == null || password.isEmpty || !context.mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await Api.deleteAccount(password);
      await Api.logout();
      if (!context.mounted) return;
      Navigator.of(context).popUntil((r) => r.isFirst);
      onLogout();
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Could not delete account: $e')));
    }
  }

  void _doc(BuildContext context, String title, List<(String, String)> sections) {
    Navigator.push(
      context,
      MaterialPageRoute<void>(builder: (_) => _InfoPage(title: title, sections: sections)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final admin = isAdminUser(user);
    final verified = isVerifiedUser(user);
    final statusColor = admin ? kAdminGold : (verified ? kVerifiedBlue : OsColors.amber);
    final name = (user['display_name'] ?? 'You').toString();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          OsCard(
            child: Row(children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: OsColors.purpleDeep,
                child: Text(name.isEmpty ? '?' : name[0].toUpperCase(),
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(name,
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  Text((user['email'] ?? '').toString(),
                      style: const TextStyle(color: OsColors.muted, fontSize: 12)),
                  const SizedBox(height: 6),
                  Row(children: [
                    Icon(verified ? Icons.verified : Icons.shield_outlined,
                        size: 15, color: statusColor),
                    const SizedBox(width: 5),
                    Text(admin ? 'OS Support' : (verified ? 'Verified' : 'Not verified yet'),
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: statusColor)),
                  ]),
                ]),
              ),
            ]),
          ),
          const _Label('Features'),
          _Tile(Icons.record_voice_over_rounded, 'Blind voice date', () {
            Navigator.push(context, MaterialPageRoute<void>(builder: (_) => BlindDateScreen(user: user)));
          }),
          _Tile(Icons.health_and_safety_rounded, 'Date safety kit', () {
            Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const SafetyKitScreen()));
          }),
          const _Label('Safety'),
          _Tile(Icons.health_and_safety_outlined, 'Safety tips', () => _doc(context, 'Safety tips', _safety)),
          _Tile(Icons.rule_rounded, 'Community guidelines', () => _doc(context, 'Community guidelines', _guidelines)),
          const _Label('Legal'),
          _Tile(Icons.lock_outline, 'Privacy & verification media', () => _doc(context, 'Privacy', _privacy)),
          const _Label('About'),
          _Tile(Icons.info_outline, 'About OS', () {
            showAboutDialog(
              context: context,
              applicationName: 'OS — Real Connections',
              applicationVersion: '1.0.0',
              applicationLegalese: 'Built with immense love ❤️',
            );
          }),
          if (!admin) ...[
            const _Label('Account'),
            _Tile(Icons.delete_outline_rounded, 'Delete account',
                () => _deleteAccount(context),
                color: Colors.red),
          ],
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: () => _confirmLogout(context),
            icon: const Icon(Icons.logout_rounded, color: OsColors.coral),
            label: const Text('Sign out', style: TextStyle(color: OsColors.coral)),
            style: OutlinedButton.styleFrom(side: const BorderSide(color: OsColors.coral)),
          ),
        ],
      ),
    );
  }

  static const _safety = [
    ('Keep it on the app', 'Stay in OS chat until you trust someone. Never share financial details, passwords or codes.'),
    ('Meet safely', 'Meet in a public place, tell a friend where you are going and arrange your own transport.'),
    ('Trust your instincts', 'If something feels off, block and report. Our moderators review every report.'),
  ];
  static const _guidelines = [
    ('Be real', 'Use your own photos and identity. Fake profiles are removed.'),
    ('Be respectful', 'No harassment, hate, threats or unwanted explicit content.'),
    ('18+ only', 'OS is strictly for adults. Accounts of under-18s are suspended.'),
    ('Consent matters', 'Respect a no. Repeated unwanted contact leads to suspension.'),
  ];
  static const _privacy = [
    ('Verification media', 'Your liveness video and comparison photo are used only to confirm you are real and are reviewed privately by authorized moderators.'),
    ('Your profile photo', 'You can hide your profile photo anytime from the You tab.'),
    ('Location', 'Location is used only to show distance to others when you choose Nearby.'),
  ];
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 14, 0, 8),
        child: Text(text.toUpperCase(),
            style: const TextStyle(
                color: OsColors.muted, fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.w800)),
      );
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final Color? color;
  const _Tile(this.icon, this.title, this.onTap, {this.color});
  @override
  Widget build(BuildContext context) => OsCard(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        onTap: onTap,
        child: Row(children: [
          Icon(icon, color: color ?? OsColors.purple),
          const SizedBox(width: 14),
          Expanded(child: Text(title, style: TextStyle(fontWeight: FontWeight.w700, color: color))),
          const Icon(Icons.chevron_right, color: OsColors.muted),
        ]),
      );
}

class _InfoPage extends StatelessWidget {
  final String title;
  final List<(String, String)> sections;
  const _InfoPage({required this.title, required this.sections});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            for (final s in sections)
              OsCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.$1, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  const SizedBox(height: 6),
                  Text(s.$2, style: const TextStyle(color: OsColors.muted, height: 1.5)),
                ]),
              ),
          ],
        ),
      );
}

/// Owns its text controller so it is disposed only when the dialog route
/// is really gone (not while the close animation is still running).
class _DeleteAccountDialog extends StatefulWidget {
  const _DeleteAccountDialog();
  @override
  State<_DeleteAccountDialog> createState() => _DeleteAccountDialogState();
}

class _DeleteAccountDialogState extends State<_DeleteAccountDialog> {
  final _password = TextEditingController();

  @override
  void dispose() {
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        backgroundColor: OsColors.surface,
        title: const Text('Permanently delete your account?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'This deletes your profile, posts, conversations and associated '
              'app records. This cannot be undone.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _password,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Confirm your password'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, _password.text),
            child: const Text('Delete account'),
          ),
        ],
      );
}