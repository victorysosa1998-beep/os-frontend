import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../theme/os_ui.dart';

class OnboardingScreen extends StatefulWidget {
  final VoidCallback onDone;
  const OnboardingScreen({super.key, required this.onDone});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _page = PageController();
  int index = 0;

  static const _slides = [
    (
      Icons.verified_user_rounded,
      'Verified Profiles only',
      'Every member passes a quick liveness check, so the person you meet is the person in the photo.'
    ),
    (
      Icons.explore_rounded,
      'Discover people near you',
      'Browse the feed, find people by city or distance, and send a connection request when something clicks.'
    ),
    (
      Icons.chat_bubble_rounded,
      'Chat once you both agree',
      'Conversations only open after a request is accepted. You are always in control, with block and report one tap away.'
    ),
  ];

  @override
  void dispose() {
    _page.dispose();
    super.dispose();
  }

  void next() {
    if (index == _slides.length - 1) {
      widget.onDone();
    } else {
      _page.nextPage(
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeOutCubic);
    }
  }

  @override
  Widget build(BuildContext context) {
    final last = index == _slides.length - 1;
    return Scaffold(
      body: OsBackground(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 12, 12, 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const OsLogo(size: 36),
                    AnimatedOpacity(
                      opacity: last ? 0 : 1,
                      duration: const Duration(milliseconds: 200),
                      child: TextButton(
                          onPressed: last ? null : widget.onDone,
                          child: const Text('Skip')),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: PageView.builder(
                  controller: _page,
                  itemCount: _slides.length,
                  onPageChanged: (i) => setState(() => index = i),
                  itemBuilder: (_, i) {
                    final s = _slides[i];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 132,
                            height: 132,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: OsColors.brandGradient,
                              boxShadow: [
                                BoxShadow(
                                    color: OsColors.purpleDeep
                                        .withValues(alpha: .45),
                                    blurRadius: 50,
                                    spreadRadius: 4),
                              ],
                            ),
                            child: Icon(s.$1, size: 60, color: Colors.white),
                          ),
                          const SizedBox(height: 44),
                          Text(s.$2,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w900,
                                  letterSpacing: -.6)),
                          const SizedBox(height: 14),
                          Text(s.$3,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  color: OsColors.muted,
                                  fontSize: 15,
                                  height: 1.5)),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(
                  _slides.length,
                  (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: i == index ? 26 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: i == index ? OsColors.purple : OsColors.border,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 28, 24, 28),
                child: OsGradientButton(
                  label: last ? 'Get started' : 'Next',
                  icon: Icons.arrow_forward_rounded,
                  onPressed: next,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
