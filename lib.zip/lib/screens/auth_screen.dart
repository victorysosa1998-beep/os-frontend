import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/biometric_auth_service.dart';

import '../services/api.dart';
import 'forgot_password_screen.dart';
import '../data/nigerian_states.dart';
import '../theme/app_theme.dart';
import '../theme/os_ui.dart';
import '../theme/user_badge.dart';

class AuthScreen extends StatefulWidget {
  final void Function(Map<String, dynamic>) onDone;

  const AuthScreen({
    super.key,
    required this.onDone,
  });

  @override
  State<AuthScreen> createState() => _AuthState();
}

class _AuthState extends State<AuthScreen> {
  final GlobalKey<FormState> form = GlobalKey<FormState>();

  final TextEditingController email = TextEditingController();
  final TextEditingController pass = TextEditingController();
  final TextEditingController name = TextEditingController();
  final TextEditingController city = TextEditingController();
  final TextEditingController phone = TextEditingController();
  final TextEditingController dob = TextEditingController();

  bool login = true;
  bool busy = false;
  bool obscure = true;
  bool enableBiometric = false;
  bool biometricEnabled = false;

  String gender = 'female';
  String? error;

  @override
  void initState() {
    super.initState();
    _loadRememberedEmail();
    _loadBiometricSetting();
  }

  Future<void> _loadRememberedEmail() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('os_last_email');
    if (mounted) setState(() {
      if (email.text.isEmpty && saved != null) email.text = saved;
      enableBiometric = prefs.getBool('os_biometric_enabled') ?? false;
      biometricEnabled = enableBiometric;
    });
  }

  Future<void> _loadBiometricSetting() async {
    final enabled = await Api.biometricLoginEnabled();
    if (mounted) setState(() { biometricEnabled = enabled; enableBiometric = enabled; });
  }

  Future<void> _loginWithBiometric() async {
    if (busy) return;
    setState(() { busy = true; error = null; });
    try {
      final hasToken = await Api.token();
      if (hasToken == null || hasToken.isEmpty) {
        await Api.setBiometricLoginEnabled(false);
        if (mounted) setState(() { biometricEnabled = false; enableBiometric = false; error = 'Your saved session has expired. Sign in with your password first.'; });
        return;
      }
      final authenticated = await BiometricAuthService.authenticate();
      if (!authenticated) {
        if (mounted) setState(() => error = 'Fingerprint verification was cancelled or unavailable. You can sign in with your password.');
        return;
      }
      final user = await Api.me();
      if (!mounted) return;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('os_last_email', email.text.trim());
      widget.onDone(user);
    } catch (e) {
      if (e is ApiException && e.isAuth) {
        await Api.logout();
        if (mounted) setState(() { biometricEnabled = false; enableBiometric = false; });
      }
      if (!mounted) return;
      setState(() => error = 'Could not restore your session. Please sign in with your password.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose();
    pass.dispose();
    name.dispose();
    city.dispose();
    phone.dispose();
    dob.dispose();
    super.dispose();
  }

  String? validateEmail(String? value) {
    final input = value?.trim() ?? '';
    final emailPattern =
        RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

    if (input.isEmpty || !emailPattern.hasMatch(input)) {
      return 'Enter a valid email address';
    }

    return null;
  }

  String? validatePassword(String? value) {
    if (value == null || value.length < 10) {
      return 'Use at least 10 characters';
    }

    return null;
  }

  String? validateDateOfBirth(String? value) {
    final input = value?.trim() ?? '';

    if (input.isEmpty) {
      return 'Enter your date of birth';
    }

    final parsed = DateTime.tryParse(input);

    if (parsed == null ||
        parsed.year < 1900 ||
        parsed.isAfter(DateTime.now()) ||
        parsed.year.toString().padLeft(4, '0') !=
            input.split('-').first) {
      return 'Use YYYY-MM-DD format';
    }

    // DateTime.tryParse can normalize some invalid dates.
    final parts = input.split('-');
    if (parts.length != 3 ||
        parts[0].length != 4 ||
        parts[1].length != 2 ||
        parts[2].length != 2 ||
        parsed.year.toString().padLeft(4, '0') != parts[0] ||
        parsed.month.toString().padLeft(2, '0') != parts[1] ||
        parsed.day.toString().padLeft(2, '0') != parts[2]) {
      return 'Enter a valid date in YYYY-MM-DD format';
    }

    final today = DateTime.now();
    var age = today.year - parsed.year;

    if (today.month < parsed.month ||
        (today.month == parsed.month && today.day < parsed.day)) {
      age--;
    }

    if (age < 18) {
      return 'You must be at least 18 to join OS';
    }

    return null;
  }


  Future<void> go() async {
    FocusScope.of(context).unfocus();

    if (busy) return;

    if (!(form.currentState?.validate() ?? false)) {
      return;
    }

    setState(() {
      busy = true;
      error = null;
    });

    try {
      final Map<String, dynamic> user;

      if (login) {
        user = await Api.login(
          email.text.trim(),
          pass.text,
        );
      } else {
        user = await Api.signup({
          'email': email.text.trim(),
          'password': pass.text,
          'display_name': name.text.trim(),
          'gender': gender,
          'date_of_birth': dob.text.trim(),
          'city': city.text.trim(),
          'phone': phone.text.trim(),
        });
      }

      if (!mounted) return;

      if (login && !enableBiometric && biometricEnabled) {
        await Api.setBiometricLoginEnabled(false);
        if (mounted) setState(() => biometricEnabled = false);
      }

      if (login && enableBiometric) {
        final available = await BiometricAuthService.isAvailable();
        if (!available) {
          await Api.setBiometricLoginEnabled(false);
          if (mounted) setState(() { biometricEnabled = false; enableBiometric = false; });
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Fingerprint authentication is not set up on this device. You are still signed in.')),
          );
        } else {
          final verified = await BiometricAuthService.authenticate(
            reason: 'Confirm fingerprint login for OS Dating',
          );
          if (verified) {
            await Api.setBiometricLoginEnabled(true);
            if (mounted) setState(() => biometricEnabled = true);
          } else {
            await Api.setBiometricLoginEnabled(false);
            if (mounted) setState(() { biometricEnabled = false; enableBiometric = false; });
          }
        }
      }

      // Email verification is mandatory: main.dart shows EmailVerificationGate until
      // the member enters the code, and the backend refuses other requests until then.

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('os_last_email', email.text.trim());
      widget.onDone(user);
    } catch (e) {
      if (!mounted) return;

      setState(() {
        error = e
            .toString()
            .replaceFirst(RegExp(r'^Exception:\s*'), '')
            .trim();
      });
    } finally {
      if (mounted) {
        setState(() {
          busy = false;
        });
      }
    }
  }

  Future<void> resetPassword() async {
    final targetEmail = email.text.trim();
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => ForgotPasswordScreen(initialEmail: targetEmail),
      ),
    );
    if (result == true && mounted) {
      setState(() {
        login = true;
        pass.clear();
        error = 'Password reset successfully. Sign in with your new password.';
      });
    }
  }

  InputDecoration dec(String label) {
    return InputDecoration(labelText: label);
  }

  void toggleMode() {
    if (busy) return;

    setState(() {
      login = !login;
      error = null;
      form.currentState?.reset();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: OsBackground(
        child: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const _Brand(),
                  const SizedBox(height: 34),
                  Text(
                    login
                        ? 'Welcome back.'
                        : 'Create your OS account.',
                    style: const TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      letterSpacing: -1,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    login
                        ? 'Your people are waiting.'
                        : 'Real people. Real moments. Real connections.',
                    style: const TextStyle(color: OsColors.muted),
                  ),
                  const SizedBox(height: 28),

                  if (error != null) ...[
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(13),
                      margin: const EdgeInsets.only(bottom: 14),
                      decoration: BoxDecoration(
                        color: OsColors.coral.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Text(
                        error!,
                        style: const TextStyle(color: OsColors.coral),
                      ),
                    ),
                  ],

                  Form(
                    key: form,
                    child: Column(
                      children: [
                        if (!login) ...[
                          TextFormField(
                            controller: name,
                            textCapitalization: TextCapitalization.words,
                            enabled: !busy,
                            decoration: dec('Display name'),
                            validator: (value) {
                              if (value == null ||
                                  value.trim().length < 2) {
                                return 'Enter your name';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 12),
                        ],

                        if (!login) ...[
                          TextFormField(
                            controller: phone,
                            enabled: !busy,
                            keyboardType: TextInputType.phone,
                            textInputAction: TextInputAction.next,
                            decoration: dec('Phone number (optional, include country code)'),
                            validator: (value) {
                              final valueText = value?.trim() ?? '';
                              if (valueText.isNotEmpty && valueText.replaceAll(RegExp(r'[^0-9]'), '').length < 7) {
                                return 'Enter a valid phone number';
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 12),
                        ],

                        TextFormField(
                          controller: email,
                          enabled: !busy,
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          autofillHints: const [AutofillHints.email],
                          autocorrect: false,
                          decoration: dec('Email'),
                          validator: validateEmail,
                        ),
                        const SizedBox(height: 12),

                        TextFormField(
                          controller: pass,
                          enabled: !busy,
                          obscureText: obscure,
                          textInputAction: login
                              ? TextInputAction.done
                              : TextInputAction.next,
                          autofillHints: [
                            login
                                ? AutofillHints.password
                                : AutofillHints.newPassword,
                          ],
                          onFieldSubmitted: (_) {
                            if (login) go();
                          },
                          decoration: dec('Password').copyWith(
                            suffixIcon: IconButton(
                              tooltip: obscure
                                  ? 'Show password'
                                  : 'Hide password',
                              onPressed: () {
                                setState(() {
                                  obscure = !obscure;
                                });
                              },
                              icon: Icon(
                                obscure
                                    ? Icons.visibility_outlined
                                    : Icons.visibility_off_outlined,
                              ),
                            ),
                          ),
                          validator: validatePassword,
                        ),

                        if (!login) ...[
                          const SizedBox(height: 12),
                          TextFormField(
                            controller: dob,
                            enabled: !busy,
                            keyboardType: TextInputType.datetime,
                            decoration: dec(
                              'Date of birth (YYYY-MM-DD)',
                            ).copyWith(
                              hintText: '2000-05-21',
                              suffixIcon: IconButton(
                                tooltip: 'Choose date',
                                onPressed: busy
                                    ? null
                                    : () async {
                                        final now = DateTime.now();
                                        final latest = DateTime(
                                          now.year - 18,
                                          now.month,
                                          now.day,
                                        );

                                        final picked = await showDatePicker(
                                          context: context,
                                          initialDate: latest,
                                          firstDate: DateTime(1900),
                                          lastDate: latest,
                                          helpText: 'Date of birth',
                                        );

                                        if (picked != null && mounted) {
                                          dob.text =
                                              '${picked.year.toString().padLeft(4, '0')}-'
                                              '${picked.month.toString().padLeft(2, '0')}-'
                                              '${picked.day.toString().padLeft(2, '0')}';
                                        }
                                      },
                                icon: const Icon(
                                  Icons.calendar_month_outlined,
                                ),
                              ),
                            ),
                            validator: validateDateOfBirth,
                          ),
                          const SizedBox(height: 12),

                          DropdownButtonFormField<String>(
                            value: gender,
                            decoration: dec('Gender'),
                            items: const [
                              DropdownMenuItem(
                                value: 'female',
                                child: Text('Female'),
                              ),
                              DropdownMenuItem(
                                value: 'male',
                                child: Text('Male'),
                              ),
                            ],
                            onChanged: busy
                                ? null
                                : (value) {
                                    if (value != null) {
                                      setState(() {
                                        gender = value;
                                      });
                                    }
                                  },
                          ),
                          const SizedBox(height: 12),

                          DropdownButtonFormField<String>(
                            value: nigerianStates.contains(city.text) ? city.text : null,
                            decoration: dec('State / FCT'),
                            isExpanded: true,
                            items: nigerianStates.map((state) => DropdownMenuItem<String>(
                              value: state, child: Text(state),
                            )).toList(),
                            onChanged: busy ? null : (value) {
                              if (value != null) setState(() => city.text = value);
                            },
                            validator: (value) => (value == null || value.isEmpty)
                                ? 'Select your state or the FCT' : null,
                          ),
                        ],

                        const SizedBox(height: 22),
                        OsGradientButton(
                          label: login ? 'Sign in' : 'Join OS',
                          busy: busy,
                          onPressed: go,
                        ),
                        if (login) ...[
                          CheckboxListTile(
                            contentPadding: EdgeInsets.zero,
                            dense: true,
                            visualDensity: VisualDensity.compact,
                            value: enableBiometric,
                            onChanged: busy ? null : (value) => setState(() => enableBiometric = value ?? false),
                            title: const Text(
                              'Use fingerprint login',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
                            ),
                            subtitle: const Text(
                              'Needs a fingerprint set up on this phone',
                              style: TextStyle(fontSize: 12, color: OsColors.muted),
                            ),
                            controlAffinity: ListTileControlAffinity.leading,
                          ),
                          if (biometricEnabled) ...[
                            const SizedBox(height: 4),
                            OutlinedButton.icon(
                              onPressed: busy ? null : _loginWithBiometric,
                              icon: const Icon(Icons.fingerprint),
                              label: const Text('Sign in with fingerprint'),
                              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                            ),
                          ],
                          Align(alignment: Alignment.centerRight, child: TextButton(onPressed: busy ? null : resetPassword, child: const Text('Forgot password?'))),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 18),
                  Center(
                    child: TextButton(
                      onPressed: busy ? null : toggleMode,
                      child: Text(
                        login
                            ? 'Create an account'
                            : 'I already have an account',
                      ),
                    ),
                  ),

                  if (!login)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'By joining OS, you confirm you are 18 or older, '
                        'agree to our community rules, and understand '
                        'that verification media is reviewed privately '
                        'by authorized moderators.',
                        style: TextStyle(
                          color: OsColors.muted,
                          fontSize: 11,
                          height: 1.45,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
      ),
    );
  }
}

class _Brand extends StatelessWidget {
  const _Brand();

  @override
  Widget build(BuildContext context) => const OsLogo(size: 58);
}